import React from 'react'
import styles from './Home.module.css'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { requestURL } from './ReqUrl'

const AdminSideBar = (props) =>{
    const navigate = useNavigate()

    const LogoutHandler = () => {
        axios
          .get(`${requestURL}/ins-logout`, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
            },
            withCredentials: "include",
          })
          .then((res) => {
            localStorage.removeItem('adminId')
            setTimeout(() => {
              navigate("/login", { replace: true });
            }, 100);
          })
          .catch((e) => {
            alert("something went wrong");
          });
      };

return (
    <>
        <div
                    className={`${styles.dabout} `}
                    onClick={() => navigate(`/admindashboard/${props.aid}`)}
                  >
                    <i className="fas fa-home"></i> Dashboard
                  </div>
                  <div
                    className={`${styles.dabout} `}
                    onClick={() => navigate(`/admin/insrequests/${props.aid}`)}
                  >
                    <i className="fas fa-university"></i> Institutes
                  </div>
                  <div className={`${styles.dabout}`}
                  onClick={() => navigate(`/admin/usersrequest/${props.aid}`)}
                  >
                    <i className="fas fa-users"></i> Users
                  </div>
                  <div className={`${styles.dabout}`}
                  onClick={() => navigate(`/admindashboard/${props.aid}/ins/id-card`)}
                  >
                    <i className="fas fa-money-bill-alt"></i> Id Card
                  </div>
                  <div className={`${styles.dabout}`}
                  onClick={() => navigate(`/admindashboard/${props.aid}/bank/details`)}
                  >
                    <i className="fas fa-money-bill-alt"></i> Transaction
                  </div>
                  <div className={`${styles.dabout}`}>
                    <i className="fas fa-envelope-open-text"></i> Support
                  </div>
                  <div className={`${styles.dabout}`}>
                    <i className="fas fa-flag-checkered"></i> Reported Content
                  </div>

                  <div className={`${styles.dabout} `}>
                    <i className="fas fa-file-alt"></i> Terms &amp; Conditions
                  </div>
                  <div className={`${styles.dabout} `} onClick={LogoutHandler}>
                    <i className="fas fa-sign-out-alt"></i> Logout
                  </div>
    </>
)
}

export default AdminSideBar;