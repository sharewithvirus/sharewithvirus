// const requestURL = "http://44.200.201.35:8080";
const requestURL = "http://localhost:8080";
export { requestURL };
