import React from "react";
import styles from "Loder.module.css";
const Loder = () => {
  return (
    <>
      <div class={styles.loader1}>
        <img src="/images/loader.svg" alt="Loading" />
      </div>
    </>
  );
};

export default Loder;
