// import styles from './Demo.module.css'

// const Demo = ()=>{
//   return (
//     <div>
//       {/* <label className={styles.label}>
//       <div className={styles.toggle}>
//         <input className={styles.toggleState} type="checkbox" name="check" value="check" />
//       <div className={styles.indicator}></div>
//     </div>
// </label> */}
// <div className={styles.toggleWrapper}>
//   <div className={styles.togglenormal}>
//     <input id={styles.normal} type="checkbox"/>
//     <label className={styles.toggleitem} for="normal"></label>
//   </div>
//   <div className={styles.name}>Normal</div>
// </div>
//     </div>
//   )
// }

// export default Demo