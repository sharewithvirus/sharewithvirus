// import React, { useState, useEffect } from "react";
// import { useNavigate, useParams } from "react-router";
// import styles from "./Home.module.css";
// import "bootstrap/dist/css/bootstrap.min.css";

// const ProfileSectionsInfo = (props) => {
//   const navigate = useNavigate();

//   return (
//     <>
//       {props.iid ?
//       <p className={` mt-4 ${styles.dashIcon} ${styles.dashIconsInner}`}>
//         <span onClick={() => navigate(`/${props.uid ? props.uid : ''}/search/insdashboard/${props.id}`)}>
//           <i class="fas fa-th"></i>
//         </span>
//         <span onClick={() => navigate(`/${props.uid ? props.uid : ''}/search/insdashboard/info/${props.id}`)}>
//           <i class="fas fa-info-circle"></i>
//         </span>
//       </p>
//       : ''}
//     </>
//   );
// };

// export default ProfileSectionsInfo;
